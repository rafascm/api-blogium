import express, { Request, Response } from 'express'
import fs from 'fs'
import path from 'path'
import { userSchema, User } from './models/user'
import cors from 'cors'

const app = express()
app.use(cors())
app.use(express.json())

const users: Array<any> = [...JSON.parse(
  fs.readFileSync(path.resolve('./data/users.json')).toString()
)]

const updateFile = (filename: string, arr: Array<any>) =>
  fs.writeFileSync(filename, JSON.stringify(arr))

let countID = 0

app.post('/', (req: Request, res: Response) => {
  if (userSchema.validate(req.body)) return res.sendStatus(400)

  users.push({ ...req.body, id: countID++ })
  updateFile('./data/users.json', users)
  res.sendStatus(200)
})

app.listen(3000)
